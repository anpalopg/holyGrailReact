const mongoose = require("mongoose");

const productSchema = new mongoose.Schema({
  nombre: String,
  precio: Number,
  img: String,
});

module.exports = mongoose.model("Producto", productSchema);
