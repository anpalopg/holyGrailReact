const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
const Producto = require("./modelo/producto"); 

// Singleton de conexión a Mongo
class Database {
  constructor() {
    if (!Database.instance) {
      mongoose.connect("mongodb://127.0.0.1:27017/tienda", {
        useNewUrlParser: true,
        useUnifiedTopology: true,
      });
      console.log("Conectado a la base de datos");
      Database.instance = this;
    }
    return Database.instance;
  }
}
new Database();

// Configuración Express
const app = express();
app.use(cors());
app.use(express.json());

// Rutas API

// Obtener todos los productos
app.get("/api/products", async (req, res) => {
  const productos = await Producto.find();
  res.json(productos);
});

// Insertar un nuevo producto
app.post("/api/products", async (req, res) => {
  try {
    const { nombre, precio, img } = req.body;
    const nuevo = new Producto({ nombre, precio, img });
    await nuevo.save();
    res.status(201).json(nuevo);
  } catch (error) {
    res.status(400).json({ error: "No se pudo guardar el producto" });
  }
});

// Iniciar servidor
const PORT = 4000;
app.listen(PORT, () => {
  console.log(`Servidor corriendo en http://localhost:${PORT}`);
});
