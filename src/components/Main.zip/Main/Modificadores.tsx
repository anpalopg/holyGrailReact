import "./Main.css";
import Main from "./Main";


export default function Modificador () {

    const varaside= "Este es el lado derecho";    
    const vararticle="Este es el contenido principal";
    const varmenu="Este es el lado izquierdo";


    
    return <Main varaside={varaside} vararticle={vararticle} varmenu={varmenu}/> 

}